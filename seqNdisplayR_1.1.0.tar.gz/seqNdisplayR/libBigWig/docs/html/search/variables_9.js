var searchData=
[
  ['m_263',['m',['../structbwOverlappingIntervals__t.html#a090dfd56a5e7bd7db60f670bc61dd49a',1,'bwOverlappingIntervals_t::m()'],['../structbbOverlappingEntries__t.html#a7bf442cf68923ab4989914ac4a27812c',1,'bbOverlappingEntries_t::m()']]],
  ['maxval_264',['maxVal',['../structbigWigHdr__t.html#aff0c5d8df557a93e3b50f448992a3f71',1,'bigWigHdr_t']]],
  ['membuf_265',['memBuf',['../structURL__t.html#ad1d920711f91f388ce7115341b3907cf',1,'URL_t']]],
  ['minval_266',['minVal',['../structbigWigHdr__t.html#a67b5de0ad0290fa5b43ef13856a3bc0a',1,'bigWigHdr_t']]]
];
