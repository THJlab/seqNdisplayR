var searchData=
[
  ['offset_277',['offset',['../structbwOverlapIterator__t.html#a0c34bec4eecfe96b84e7038b45b0433e',1,'bwOverlapIterator_t::offset()'],['../structbwOverlapBlock__t.html#a0bfe76443d7c7bcb60e666eb04594f94',1,'bwOverlapBlock_t::offset()']]]
];
