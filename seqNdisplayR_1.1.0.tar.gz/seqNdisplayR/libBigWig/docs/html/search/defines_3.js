var searchData=
[
  ['idx_5fmagic_318',['IDX_MAGIC',['../bigWig_8h.html#a28c6eb6ee75c6082e8df04dba8c7f32e',1,'bigWig.h']]]
];
