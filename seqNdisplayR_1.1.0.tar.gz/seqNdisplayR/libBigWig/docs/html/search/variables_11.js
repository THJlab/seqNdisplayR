var searchData=
[
  ['value_294',['value',['../structbwOverlappingIntervals__t.html#a1945a25b881f5b94ecccaf57bb43291b',1,'bwOverlappingIntervals_t']]],
  ['version_295',['version',['../structbigWigHdr__t.html#ac0c3543680ec2b5b40015421788981a6',1,'bigWigHdr_t']]]
];
