var searchData=
[
  ['baseend_218',['baseEnd',['../structbwRTreeNode__t.html#a2780034368ea3ec077c2b6d7bf16aff6',1,'bwRTreeNode_t::baseEnd()'],['../structbwRTree__t.html#a656f53ca34361b368fc3fd1710f0de42',1,'bwRTree_t::baseEnd()']]],
  ['basestart_219',['baseStart',['../structbwRTreeNode__t.html#af8a64d389746640ca8b67a0e060792c4',1,'bwRTreeNode_t::baseStart()'],['../structbwRTree__t.html#adde0db0e9555b457c074d1eacae1c02f',1,'bwRTree_t::baseStart()']]],
  ['blocks_220',['blocks',['../structbwOverlapIterator__t.html#af2c02ec44c6c5a202874e79d9e2fca40',1,'bwOverlapIterator_t']]],
  ['blocksize_221',['blockSize',['../structbwWriteBuffer__t.html#a39aa0458ab26dbbc1e0edf47eb7f903d',1,'bwWriteBuffer_t::blockSize()'],['../structbwRTree__t.html#a430220a665cfcc8c76e372dc8f221b2f',1,'bwRTree_t::blockSize()']]],
  ['blocksperiteration_222',['blocksPerIteration',['../structbwOverlapIterator__t.html#a401ea1885855ff8b4285fc289aa281cf',1,'bwOverlapIterator_t']]],
  ['buflen_223',['bufLen',['../structURL__t.html#a2d3601123cd3d99cc184461007572b9f',1,'URL_t']]],
  ['bufpos_224',['bufPos',['../structURL__t.html#ad560759e3af5e982fd369a27ba5b1dbc',1,'URL_t']]],
  ['bufsize_225',['bufSize',['../structbigWigHdr__t.html#af4b63611a0ec7f7f63fc7218bd35a2c0',1,'bigWigHdr_t::bufSize()'],['../structURL__t.html#a4f68a10b5d2284fd756562ea7bd02abc',1,'URL_t::bufSize()']]],
  ['bw_226',['bw',['../structbwOverlapIterator__t.html#a93633b2c6c6dc1c1f3b26332924e5231',1,'bwOverlapIterator_t']]]
];
