var searchData=
[
  ['bigwigfile_5ftype_5fenum_301',['bigWigFile_type_enum',['../bigWigIO_8h.html#a53551ff2ef7a2c1b938e94ef9592ab66',1,'bigWigIO.h']]],
  ['bwstatstype_302',['bwStatsType',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22c',1,'bigWig.h']]]
];
