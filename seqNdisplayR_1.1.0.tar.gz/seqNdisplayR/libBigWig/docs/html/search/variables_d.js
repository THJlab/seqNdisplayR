var searchData=
[
  ['root_279',['root',['../structbwRTree__t.html#ad4566d3fdd23ac4918104d23c77a7ddb',1,'bwRTree_t']]],
  ['rootoffset_280',['rootOffset',['../structbwRTree__t.html#aa3e57a494e0c45d56dca1de0939e8197',1,'bwRTree_t']]],
  ['runningwidthsum_281',['runningWidthSum',['../structbwWriteBuffer__t.html#a395634c6f60756abb87013a11f68b293',1,'bwWriteBuffer_t']]]
];
