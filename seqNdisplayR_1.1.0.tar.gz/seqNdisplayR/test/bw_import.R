#' Import a BigWig region like rtracklayer::import(..., as="NumericList")[[1]]
#'
#' @param bw_file Path to BigWig file
#' @param chrom Chromosome name (e.g., "chr1")
#' @param start Start coordinate (1-based)
#' @param end End coordinate (1-based, inclusive)
#' @param envname Reticulate environment name (default: "r-reticulate")
#' @return Numeric vector of signal values with 0 where data are missing
#' @examples
#' vals <- bw_import("example.bw", "chr1", 1000, 2000)
#'
bw_import <- function(bw_file, chrom, start, end, envname = "r-reticulate") {
  library(reticulate)
  # ensure environment is used
  use_condaenv(envname, required = TRUE)
  # import pyBigWig
  pybw <- reticulate::import("pyBigWig")
  # open file
  bw <- pybw$open(bw_file)
  # extract values (note: pyBigWig uses 0-based start, end-exclusive)
  vals <- bw$values(chrom, as.integer(start - 1L), as.integer(end))
  # close file
  bw$close()
  # convert None → 0 and to numeric vector
  vals <- sapply(vals, function(x) if (is.null(x) || is.nan(x)) 0 else x)
  as.numeric(vals)
}
